Datasets:
Special Events Data found in project description
FBI UCR data found here: https://crime-data-explorer.fr.cloud.gov/pages/le/pe
Other Boston government data found here: https://data.boston.gov/

Requirements:
- Install GT America Bold and GT America Regular from the font folder to view plotly plots